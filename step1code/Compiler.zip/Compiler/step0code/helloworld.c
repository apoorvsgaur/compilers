#include <stdio.h>

int main (int argc, char **argv)
{
		  printf ("Welcome to the world of compilers\n");
		  return 0;
}
