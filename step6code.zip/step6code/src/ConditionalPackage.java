import java.util.ArrayList;

/**
 * Created by brandonscheller on 11/14/16
 */
public class ConditionalPackage {
    String target1;
    String target2;
    String op;
    ConditionalPackage(String op, String target1, String target2){
        this.op = op;
        this.target1 = target1;
        this.target2 = target2;
    }
}
